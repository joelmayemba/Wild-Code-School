<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $companyName = isset($_POST["companyName"]) ? $_POST["companyName"] : "";
    $userName = isset($_POST["userName"]) ? $_POST["userName"] : "";
    $userEmail = isset($_POST["userEmail"]) ? $_POST["userEmail"] : "";
    $commercialContact = isset($_POST["commercialContact"]) ? $_POST["commercialContact"] : "";
    $contactMessage = isset($_POST["contactMessage"]) ? $_POST["contactMessage"] : "";
}

// var_dump($_POST);
$errors = [];
$minMessage = 30;
$tab = [
    ["name" => "Andy Bernard", "img" => "images/andy.webp"],
    ["name" => "Dwight Schrute", "img" => "images/dwight.webp"],
    ["name" => "Jim Halpert", "img" => "images/jim.webp"],
    ["name" => "Phyllis Lapin-Vance", "img" => "images/phyllis.webp"],
    ["name" => "Stanley Hudson", "img" => "images/stanley.webp"]
];

// TODO 3 - Get the data from the form and check for errors

if (empty($companyName)) {
    $errors[] = "Le nom de l'entreprise est obligatoire.";
}

if (empty($userName)) {
    $errors[] = "Le nom de l'utilisateur est obligatoire.";
}

if (empty($userEmail)) {
    $errors[] = "L'adresse e-mail est obligatoire.";
} elseif (!filter_var($userEmail, FILTER_VALIDATE_EMAIL)) {
    $errors[] = "L'adresse e-mail n'est pas valide.";
}

if (empty($contactMessage)) {
    $errors[] = "Le message est obligatoire.";
} elseif (strlen($contactMessage) < $minMessage) {
    $errors[] = "Le message doit faire plus de 30 caractères.";
}

// var_dump($tab["img"]); 

if (!empty($errors)) {
    require 'error.php';
    die();
}


?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Récapitulatif - Réclamation</title>
    <link rel="stylesheet" href="css/style.css">
</head>

<body>

    <header>
        <h1>Nous traitons votre retour.</h1>
        <img src="images/logo_dunder.png" alt="Logo Dunder Mifflin">
    </header>

    <main>
        <div class="summary">
            <!-- BONUS -->
            <p>
                <img src="images/placeholder.png" alt="">
                Votre vendeur : <span> <?= $commercialContact?> </span>
            </p>


            <!-- TODO 2 - Replace those placeholders by the values sent from the form -->
            <ul>
                <li>Votre entreprise : <span><?= $companyName ?></span></li>
                <li>Votre nom : <span><?= $userName ?></span></li>
                <li>Votre email : <span><?= $userEmail  ?></span></li>
                <li>Votre message : <p><?= $contactMessage ?></p>
                </li>
            </ul>

        </div>
    </main>
</body>

</html>